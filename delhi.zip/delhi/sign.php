<?php include 'header.php'; ?>


   <div class="container">
   <h1 class="welcome text-center">Sign In to Praadis</h1>
       <div class="card card-container">
       <hr>
       <form>
         <div class="form-row">
          <div class="form-group col-md-4">
            <input type="text" class="form-control"  placeholder="First Name">
          </div>
          <div class="form-group col-md-4">
            <input type="text" class="form-control"  placeholder="Middle Name">
          </div>
          <div class="form-group col-md-4">
            <input type="text" class="form-control"  placeholder="Last Name">
          </div>
         </div>
          <div class="form-row">
           <div class="form-group col-md-6">
             <input type="email" class="form-control" id="inputEmail4" placeholder="Email">
           </div>
           <div class="form-group col-md-6">
             <input type="password" class="form-control" id="inputPassword4" placeholder="Password">
           </div>
          </div>
          <div class="form-group-text">
           <input type="text" class="form-control" id="inputAddress" placeholder="1234 Main St">
          </div>
<div class="form-group">
 <input type="text" class="form-control" id="inputAddress2" placeholder="Apartment, studio, or floor">
</div>
<div class="form-row">
 <div class="form-group col-md-6">
   <input type="text" class="form-control" id="inputCity" placeholder="Your City">
 </div>
 <div class="form-group col-md-4">
   <select id="inputState" class="form-control">
     <option selected>Choose...</option>
     <option>...</option>
   </select>
 </div>
 <div class="form-group col-md-2">
   <label for="inputZip">Zip</label>
   <input type="text" class="form-control" id="inputZip">
 </div>
</div>
<div class="form-group">

</div>
<div class="loginbutton">
  <a href="#" >Sign Up</a>
</div>
</form>
       </div><!-- /card-container -->
   </div><!-- /container -->
<?php include 'footer.php'; ?>
